import{j as r}from"./index-51d7f51e.js";function e(){return r.jsx(r.Fragment,{children:"统计管理"})}export{e as default};
