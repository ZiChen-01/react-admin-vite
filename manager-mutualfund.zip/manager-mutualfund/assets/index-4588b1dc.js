import{j as r}from"./index-51d7f51e.js";function e(){return r.jsx(r.Fragment,{children:"监控数据"})}export{e as default};
