import{j as r}from"./index-e6d10f58.js";function e(){return r.jsx(r.Fragment,{children:"统计管理"})}export{e as default};
